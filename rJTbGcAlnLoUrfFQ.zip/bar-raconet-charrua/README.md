# Bar El Raconet Charrúa - Sitio Web

Sitio web profesional y responsivo para el **Bar El Raconet Charrúa**, ubicado en Barcelona. Este sitio presenta las especialidades del bar, menú completo, información de contacto y ubicación.

## 📋 Características

- **Diseño Responsivo**: Compatible con dispositivos móviles, tablets y escritorio
- **Menú Interactivo**: Pestañas para Tapas, Especiales y Postres
- **Información Completa**: Horarios, ubicación, teléfono y redes sociales
- **Integración con Google Maps**: Mapa embebido de la ubicación
- **Reseñas de Clientes**: Testimonios de clientes satisfechos
- **Botones de Acción**: Enlaces directos a plataformas de entrega (Uber Eats, Just Eat)
- **Animaciones Suaves**: Efectos visuales y transiciones elegantes
- **SEO Optimizado**: Meta tags y estructura semántica

## 🎨 Paleta de Colores

- **Color Primario**: #FF6B35 (Naranja)
- **Color Secundario**: #4A3F35 (Marrón oscuro)
- **Color Acentuado**: #FFD700 (Oro)
- **Fondo Claro**: #F5F5F5

## 📁 Estructura del Proyecto

```
bar-raconet-charrua/
├── index.html          # Página principal
├── css/
│   └── styles.css      # Estilos principales
├── js/
│   └── script.js       # Funcionalidad JavaScript
├── images/
│   ├── hero-food.jpg   # Imagen principal
│   ├── food-1.jpg      # Imagen de comida
│   └── food-2.jpg      # Imagen de comida
└── README.md           # Este archivo
```

## 🚀 Cómo Usar

### Opción 1: Abrir Localmente
1. Descarga todos los archivos
2. Abre `index.html` en tu navegador web
3. ¡Listo! El sitio se mostrará correctamente

### Opción 2: Servidor Local (Python)
```bash
cd /home/ubuntu/bar-raconet-charrua
python3 -m http.server 8000
```
Luego abre `http://localhost:8000` en tu navegador.

### Opción 3: Servidor Local (Node.js)
```bash
cd /home/ubuntu/bar-raconet-charrua
npx http-server
```

## 📱 Secciones del Sitio

### 1. Navegación
- Barra de navegación pegajosa con enlaces a todas las secciones
- Diseño responsivo que se adapta a dispositivos móviles

### 2. Hero Section
- Imagen de fondo con llamada a la acción
- Botones para pedir a domicilio y ver menú

### 3. Destacados
- 4 tarjetas con información clave del bar
- Calificación (4.7 estrellas)
- Especialidades y ambiente

### 4. Menú
- Tres categorías: Tapas, Especiales y Postres
- Descripción y precio de cada plato
- Interfaz interactiva con pestañas

### 5. Ubicación
- Información de dirección y teléfono
- Horarios de apertura
- Mapa embebido de Google Maps
- Zonas de entrega

### 6. Reseñas
- Testimonios de clientes
- Calificaciones de 5 estrellas

### 7. Contacto
- Información de contacto
- Enlaces a redes sociales
- Zonas de entrega disponibles

### 8. Footer
- Información de derechos de autor
- Ubicación del bar

## 🔧 Personalización

### Cambiar Colores
Edita las variables en `css/styles.css`:
```css
:root {
    --primary-color: #FF6B35;
    --secondary-color: #4A3F35;
    --accent-color: #FFD700;
    /* ... */
}
```

### Actualizar Menú
Edita las secciones de menú en `index.html`:
```html
<div class="menu-item">
    <h3>Nombre del Plato</h3>
    <p class="description">Descripción</p>
    <p class="price">Precio €</p>
</div>
```

### Cambiar Información de Contacto
Busca la sección de contacto en `index.html` y actualiza:
- Teléfono
- Dirección
- Horarios
- Enlaces a redes sociales

## 📞 Información del Bar

**Bar El Raconet Charrúa**
- 📍 Av. de la Mare de Déu de Montserrat, 175, Barcelona, 08041
- 📱 +34 655 07 99 90
- ⭐ 4.7 estrellas (1,246 reseñas)
- 💰 €10-20 por persona
- 📅 Abierto de lunes a domingo (cerrado martes)
- 🕐 13:00-16:00 | 18:30-23:00

## 🌐 Redes Sociales

- Instagram: [@elraconetcharrua](https://www.instagram.com/elraconetcharrua/)
- Facebook: [El Raconet](https://www.facebook.com/Elraconetdetots)

## 🚚 Plataformas de Entrega

- Uber Eats
- Just Eat
- Entrega propia en zonas de Barcelona

## 📊 Especialidades

- **Milanesas Gigantes**: Nuestro plato estrella
- **Patatas Bravas**: Con alioli casero y salsa brava
- **Tequeños**: Queso derretido en masa crujiente
- **Pimientos del Padrón**: Frescos y sabrosos
- **Empanadas**: Rellenas de carne o pollo
- **Postres**: Tiramisu, Tres Leches, Flan y Brownie

## 💡 Consejos de Uso

1. **Optimización de Imágenes**: Las imágenes están optimizadas pero puedes comprimirlas más si es necesario
2. **SEO**: El sitio incluye meta tags básicos, considera agregar más para mejor posicionamiento
3. **Accesibilidad**: El sitio es accesible pero puedes mejorar con ARIA labels
4. **Performance**: Considera agregar lazy loading para las imágenes en el futuro

## 📝 Licencia

Este sitio web fue creado para el Bar El Raconet Charrúa. Todos los derechos reservados © 2026.

## 🤝 Soporte

Para cambios o actualizaciones en el sitio, contacta con el equipo de desarrollo.

---

**Última actualización**: Abril 2026
